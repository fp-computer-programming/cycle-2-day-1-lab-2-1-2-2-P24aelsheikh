# 1) Create a Python file named lab_2-2.py

# 2) Set a equal to 3 and b equal to a

# 3) Print the value of b and the value of a.

# 4) What is the value of each variable and why? (Answer as a comment)

# 5) Set a equal to 7.

# 6) Print the value of a and the value of b

# 7) What is the value of each variable and why? (Answer as a comment)
