#Create a python file named lab_2-1.py
#Input the following into the Python interpreter and see what the output is. Be mindful of spaces. Each expression needs to be visible in your final code.
"""
123 + 321 - 321
20+ 202020 - 420 + 20
2 * 4 * 6 * 8		9 / 5		9 // 5
13/0	3 % 10	3 % 10
2 ** 3		2 * 2 * 2		0/0
"""
